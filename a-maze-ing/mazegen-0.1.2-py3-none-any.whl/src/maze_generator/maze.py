import random
import sys
from typing import Any, List, Optional
from pathlib import Path
from src.config.enums import Colors, MazeAlgorithm, Walls
from src.maze_generator.cell import Cell
from src.parser.config_model import ConfigModel


class Maze:
    """
    Maze class for generating and solving maze puzzles.

    This class provides functionality to create, manipulate, and solve mazes
    using various algorithms. It includes features for maze generation, wall
    management, pathfinding, and maze validation.

    Attributes:
        width (int): The width of the maze in cells.
        height (int): The height of the maze in cells.
        grid_maze (List[List[Cell]]): 2D grid representing the maze structure.
        build (Built_Maze): Nested class instance for maze building operations.

    Methods:
        initial_matrix() -> List[List[Cell]]:
            Initializes the maze grid with Cell objects.

        generate_seed() -> list[list]:
            Converts the maze grid into a hexadecimal seed representation where
            each cell's walls are encoded as a hex digit (N=1, E=2, S=4, W=8).

        export_seed(maze_seed: list[list], solve_directions: str,
                    maze_config: ConfigModel) -> None:
            Writes the maze seed, entry point, exit point, and solution
            directions
            to a file specified in maze_config.

    Nested Class:
        Built_Maze:
            Provides maze building and solving operations including
            pathfinding,
            algorithm selection (DFS/Prim), maze generation, and solution path
            calculation.

            Methods:
                is_within_bounds(x: int, y: int) -> bool:
                    Validates if coordinates are within maze boundaries.

                get_cell(x: int, y: int) -> Optional[Cell]:
                    Retrieves a cell at specified coordinates if within bounds.

                get_directions() -> list[tuple[str, int, int]]:
                    Returns cardinal directions (N, E, S, W) with offset
                    vectors.

                opposite_wall(wall: str) -> str:
                    Returns the opposite wall direction (N↔S, E↔W).

                get_neighbors(cell: Cell) -> List[tuple[Cell, str]]:
                    Returns unvisited neighboring cells with their wall
                    directions.

                find_direction_by_wall(wall: str) -> tuple[str, int, int]:
                    Retrieves direction tuple for a given wall.

                has_necessary_dimensions() -> bool:
                    Checks if maze meets minimum dimensions (9x7).

                calculate_init_position() -> Optional[tuple[int, int]]:
                    Calculates center position for watermark placement.

                watermark() -> bool:
                    Adds a "42" pattern watermark to the maze center.

                check_valid_position(start: tuple[int, int],
                    Validates that start and exit coordinates don't conflict
                    with the watermark pattern.

                open_areas(max_passes: int = 10) -> None:
                    Eliminates large open spaces (2x3 or 3x2) by adding walls
                    with random gaps.

                perfect_maze(start: tuple[int, int], exit: tuple[int, int],
                            algorithm: str = Maze_Algorithm.DFS.value) -> None:
                    Generates a maze using DFS or Prim's algorithm, with
                    optional non-perfect maze variations.

                find_cells_without_walls(cell: Cell) -> list[str]:
                    Returns list of wall directions that are open (not
                    present).

                get_cells_solve_maze(start: Cell, exit: Cell)
                    -> Optional[List[Cell]]:
                    Finds a path from start to exit using BFS algorithm.

                path_to_directions(path: list[Cell]) -> str:
                    Converts a cell path into a string of direction characters.

                solve_maze(start: tuple[int, int],
                    Solves the maze and returns the solution as a direction
                    string.
    """

    def __init__(self, maze_config: ConfigModel) -> None:
        """
        Initialize a Maze object.

        Args:
            maze_config (ConfigModel): The validated configuration model
            containing maze settings (dimensions, entry/exit points, etc.).

        Attributes:
            width (int): The width of the maze grid.
            height (int): The height of the maze grid.
            grid_maze (List[List[Cell]]): A 2D list representing the maze
            grid, where each element is a Cell object.
            build (Built_Maze): An instance of the Built_Maze helper class for
            maze construction operations.
        """
        self.width: int = maze_config.maze_width
        self.height: int = maze_config.maze_height
        self.grid_maze: List[List[Cell]] = []
        self.solve_maze_seed: str = ""
        self.seed_code = maze_config.maze_seed_code
        self.build = self.BuiltMaze(self)

    def initial_matrix(self) -> List[List[Cell]]:
        """
        Initialize and create the maze grid matrix.

        Creates a 2D grid of Cell objects with dimensions based on the maze's
        width and height. Each cell is instantiated with its corresponding
        (x, y) coordinates.

        Returns:
            List[List[Cell]]: A 2D list representing the maze grid, where each
                             element is a Cell object positioned at coordinates
                             (x, y) within the specified width and height
                             bounds.
        """
        self.grid_maze = [
            [Cell(x, y) for x in range(self.width)] for y in range(self.height)
        ]
        return self.grid_maze

    def generate_seed(self) -> List[List[str]]:
        """
        Generate a maze seed by encoding wall configurations of each cell.

        Converts the maze grid into a 2D list where each cell is represented
        as a hexadecimal
        digit encoding its wall states. Each wall direction is mapped to a bit:
        - North (N): 1
        - East (E): 2
        - South (S): 4
        - West (W): 8

        Returns:
            list[list]: A 2D list of hexadecimal strings representing the maze
            seed, where each element corresponds to a cell's wall
            configuration.
        """
        maze_seed: List[list[str]] = []
        i: int = 0
        for row in self.grid_maze:
            maze_seed.append([])
            for cell in row:
                cell_walls: int = 0
                if cell.walls.get("N"):
                    cell_walls += 1
                if cell.walls.get("E"):
                    cell_walls += 2
                if cell.walls.get("S"):
                    cell_walls += 4
                if cell.walls.get("W"):
                    cell_walls += 8
                # Saving in Hexadecimal format
                maze_seed[i].append(f"{cell_walls:X}")
            i += 1
        return maze_seed

    def export_seed(
        self,
        maze_seed: List[List[str]],
        solve_directions: str,
        maze_config: ConfigModel,
    ) -> None:
        """
        Export maze data to a file.

        This method writes the maze structure, entry point, exit point, and
        solution directions to a file specified in the maze configuration.

        Args:
            maze_seed (list[list]): A 2D list representing the maze structure
            where each inner list represents a row of the maze.
            solve_directions (str): A string containing the directions to
            solve the maze (e.g., "SWSES" for South, West, South, East,
            South).
            maze_config (ConfigModel): Configuration object containing maze
            output file path and entry/exit coordinates.

        Returns:
            None

        Raises:
            IOError: If the output file cannot be written.
            ValueError: If maze_config.maze_output path is invalid.
        """
        # .resolve() converts relative paths to absolute paths avoiding ./..
        base_dir = Path("./output").resolve()
        file_path = Path(base_dir / maze_config.maze_output).resolve()

        try:
            if not file_path.is_relative_to(base_dir):
                raise PermissionError("Not authorized access!")
            # Creating the output folder if it does not exist:
            file_path.parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, mode="w") as fd:
                for row in maze_seed:
                    fd.writelines(row)
                    fd.write("\n")
                fd.write("\n")
                x, y = maze_config.maze_entry
                fd.write(f"{x},{y}\n")
                x, y = maze_config.maze_exit
                fd.write(f"{x},{y}\n")
                fd.write(f"{solve_directions}")
        except (
                FileNotFoundError,
                AttributeError,
                PermissionError) as e:
            print(f"{Colors.RED.value}[ERROR] - {maze_config.maze_output}. "
                  f"{e}{Colors.RESET.value}")
            sys.exit(1)

    class BuiltMaze:
        """
        Built_Maze class for managing and manipulating maze structures.

        A comprehensive maze utility class that handles maze validation,
        navigation, generation using different algorithms (DFS, Prim's),
        solving, and special features like watermarking and open area
        management.

        Attributes:
            maze (Maze): The maze object containing grid and dimension
            information.

        Methods:
            is_within_bounds(x, y) -> bool:
                Validates if coordinates are within maze boundaries.

            get_cell(x, y) -> Optional[Cell]:
                Retrieves a cell at given coordinates, returns None if out of
                bounds.

            get_directions() -> list[tuple[str, int, int]]:
                Returns cardinal directions (N, E, S, W) with their offset
                values.

            opposite_wall(wall) -> str:
                Returns the opposite wall direction for a given wall.

            get_neighbors(cell) -> List[tuple[Cell, str]]:
                Gets unvisited neighboring cells with their connecting walls.

            find_direction_by_wall(wall) -> tuple[str, int, int]:
                Finds direction tuple matching the given wall identifier.

            has_necessary_dimensions() -> bool:
                Checks if maze meets minimum dimensions (9x7).

            calculate_init_position() -> Optional[tuple[int, int]]:
                Calculates center position for watermark placement.

            watermark() -> bool:
                Marks cells in a "42" pattern at maze center, marks them as
                visited.

            check_valid_position(start, exit) -> bool:
                Validates that start and exit coordinates are valid and not on
                watermark.

            open_areas(max_passes) -> None:
                Prevents large open spaces by adding walls to 2x3 or 3x2 areas.

            perfect_maze(start, exit, is_perfect, algorithm) -> None:
                Generates a maze using DFS or Prim's algorithm, optionally
                adds cycles.

            find_cells_without_walls(cell) -> list[str]:
                Returns list of wall directions that are open for a cell.

            get_cells_solve_maze(start, exit) -> Optional[List[Cell]]:
                Solves maze using BFS, returns ordered list of cells from
                start to exit.

            path_to_directions(path) -> str:
                Converts cell path into directional string (N/S/E/W sequence).

            solve_maze(start, exit) -> str:
                Main solver method, returns directional string or empty if no
                solution.
        """

        def __init__(self, maze: Any) -> None:
            """
            Initialize the Maze object handler.

            Args:
                maze (Any): A Maze instance to be stored and managed by this
                object.

            Attributes:
                maze (Maze): The maze object passed during initialization.
            """
            self.maze: Maze = maze

        def is_within_bounds(self, x: int, y: int) -> bool:
            """
            Check if the given coordinates are within the maze boundaries.

            Args:
                x (int): The x-coordinate to check.
                y (int): The y-coordinate to check.

            Returns:
                bool: True if the coordinates (x, y) are within the maze bounds
                      (0 <= x < width and 0 <= y < height), False otherwise.
            """
            if 0 <= x < self.maze.width and 0 <= y < self.maze.height:
                return True
            return False

        def get_cell(self, x: int, y: int) -> Optional[Cell]:
            """
            Retrieve a cell from the maze grid at the specified coordinates.

            Args:
                x (int): The x-coordinate (column) of the cell.
                y (int): The y-coordinate (row) of the cell.

            Returns:
                Optional[Cell]: The Cell object at the specified coordinates
                if the coordinates
                                are within the maze bounds, otherwise None.
            """
            if self.is_within_bounds(x, y):
                return self.maze.grid_maze[y][x]
            return None

        @staticmethod
        def get_directions() -> list[tuple[str, int, int]]:
            """
            Generate a list of cardinal directions with their corresponding
            offsets.

            Returns:
                list[tuple[str, int, int]]: A list of tuples containing:
                    - direction name (N, E, S, W as string values)
                    - x-axis offset (column delta)
                    - y-axis offset (row delta)
            """
            return [
                (Walls.N.value, 0, -1),
                (Walls.E.value, 1, 0),
                (Walls.S.value, 0, 1),
                (Walls.W.value, -1, 0),
            ]

        @staticmethod
        def opposite_wall(wall: str) -> str:
            """
            Return the opposite wall direction for a given wall.

            Args:
                wall (str): A wall direction string (N, S, E, or W).

            Returns:
                str: The opposite wall direction.
                     - N returns S (North returns South)
                     - S returns N (South returns North)
                     - E returns W (East returns West)
                     - W returns E (West returns East)

            Raises:
                KeyError: If wall is not a valid direction (N, S, E, W).
            """
            opposites = {
                Walls.N.value: Walls.S.value,
                Walls.S.value: Walls.N.value,
                Walls.E.value: Walls.W.value,
                Walls.W.value: Walls.E.value,
            }
            return opposites[wall]

        def get_neighbors(self, cell: Cell) -> List[tuple[Cell, str]]:
            """
            Retrieves unvisited neighboring cells of a given cell.

            Args:
                cell (Cell): The cell for which to find neighbors.

            Returns:
                List[tuple[Cell, str]]: A list of tuples containing unvisited
                neighbor cells
                    and the wall direction connecting to them. Each tuple
                    consists of:
                    - Cell: The neighboring cell object
                    - str: The wall identifier/direction string

            Example:
                neighbors = maze.get_neighbors(current_cell)
                for neighbor_cell, wall_direction in neighbors:
                    # Process neighbor
            """
            directions: List[tuple[str, int, int]] = self.get_directions()
            neighbors: List[tuple[Cell, str]] = []
            for wall, dir_x, dir_y in directions:
                node_x = cell.x + dir_x
                node_y = cell.y + dir_y
                neighbor: Cell | None = self.get_cell(node_x, node_y)
                if neighbor and not neighbor.visited:
                    neighbors.append((neighbor, wall))
            return neighbors

        def find_direction_by_wall(self, wall: str) -> tuple[str, int, int]:
            """
            Find the direction tuple associated with a given wall identifier.

            Args:
                wall (str): The wall identifier to search for (e.g., 'N', 'S',
                'E', 'W').

            Returns:
                tuple[str, int, int]: A tuple containing the wall identifier,
                                      x-offset (dx), and y-offset (dy) for the
                                      matching direction.

            Raises:
                StopIteration: If no direction with the given wall identifier
                is found.
            """
            return next(((w, dx, dy)
                         for w, dx, dy in self.get_directions()
                         if w == wall))

        def has_necessary_dimensions(self) -> bool:
            """
            Check if the maze has the minimum required dimensions.

            Returns:
                bool: True if the maze width is at least 9 and height is at
                least 7,
                      False otherwise.
            """
            return self.maze.width >= 9 and self.maze.height >= 7

        def calculate_init_position(self) -> Optional[tuple[int, int]]:
            """
            Calculate the initial position at the center of the maze.

            Computes the center coordinates of the maze by dividing its width
            and height by 2.
            If the dimensions are not integers, they are truncated to integers.

            Returns:
                Optional[tuple[int, int]]: A tuple of (x, y) coordinates
                representing the center position, or None if the maze does not
                have the necessary dimensions.
            """
            if not self.has_necessary_dimensions():
                return None
            x: float = self.maze.width / 2
            y: float = self.maze.height / 2

            x = x if x.is_integer() else int(x)
            y = y if y.is_integer() else int(y)

            return (int(x), int(y))

        def watermark(self) -> bool:
            """
            Mark cells in the maze to create a '42' watermark pattern.

            This method identifies and marks specific cells in the maze grid
            that form the visual representation of the numbers '4' and '2',
            creating a watermark.
            The watermark is positioned relative to the calculated initial
            position.

            Returns:
                bool: True if the watermark was successfully applied, False if
                the maze dimensions are insufficient to display the watermark.

            Note:
                - Requires the maze to have sufficient dimensions (checked via
                  has_necessary_dimensions())
                - Marks cells by setting their `is_FORTY_TWO` and `visited`
                attributes
                  to True
                - The watermark pattern is defined by two grids: one for the
                digit '4'
                  and one for the digit '2'
            """
            if not self.has_necessary_dimensions():
                print("The maze dimensions are not sufficient to print "
                      "the watermark")
                return False
            # Identify position for number four
            grid_four: set[tuple[int, int]] = {
                (-3, -2),
                (-1, -2),
                (-3, -1),
                (-1, -1),
                (-3, 0),
                (-2, 0),
                (-1, 0),
                (-1, 1),
                (-1, 2),
            }
            # Identify position for number two
            grid_two: set[tuple[int, int]] = {
                (1, -2),
                (2, -2),
                (3, -2),
                (3, -1),
                (1, 0),
                (2, 0),
                (3, 0),
                (1, 1),
                (1, 2),
                (2, 2),
                (3, 2),
            }
            grid_all: set[tuple[int, int]] = grid_four | grid_two
            start_pos: tuple[int, int] | None = self.calculate_init_position()
            start_pos_x: int = 0
            start_pos_y: int = 0
            if start_pos:
                start_pos_x, start_pos_y = start_pos

            for row in self.maze.grid_maze:
                for cell in row:
                    _x: int = cell.x - start_pos_x
                    _y: int = cell.y - start_pos_y
                    if (_x, _y) in grid_all:
                        cell.is_FORTY_TWO = True
                        cell.visited = True
            return True

        def check_valid_position(
            self, start: tuple[int, int], exit: tuple[int, int]
        ) -> bool:
            """
            Validate that the start and exit positions are valid for maze
            traversal.

            Checks that both start and exit coordinates exist within the maze
            and
            that neither position contains a cell marked with the '42' pattern.

            Args:
                start: A tuple of (row, col) coordinates for the maze start
                position.
                exit: A tuple of (row, col) coordinates for the maze exit
                position.

            Returns:
                bool: True if both positions are valid, False otherwise.

            Prints:
                - "The start or end coordinates are incorrect." if either
                coordinate
                    is out of bounds or doesn't correspond to a valid cell.
                - "The coordinates cannot match the pattern '42'" if either
                position
                    contains a cell marked with the '42' pattern.
            """
            result: bool = True
            _start: Cell | None = self.get_cell(*start)
            _end: Cell | None = self.get_cell(*exit)

            if not _start or not _end:
                print("The start or end coordinates are incorrect.")
                result = False
            if ((_start and _start.is_FORTY_TWO) or
               (_end and _end.is_FORTY_TWO)):
                print("The coordinates cannot match the pattern '42'")
                result = False
            return result

        def open_areas(self, max_passes: int = 10) -> None:
            """
            Reduce large open areas in the maze by strategically placing walls.
            This method iteratively scans the maze for rectangular open areas
            (2x3 or 3x2 cells with no internal walls) and subdivides them by
            adding walls with random gaps.
            The process continues for multiple passes until no more open areas
            are found or the maximum number of passes is reached.
            Args:
                max_passes (int, optional): Maximum number of iterations to
                scan and modify the maze. Defaults to 10. The method may
                terminate early if a complete pass finds no open areas to
                modify.
            Returns:
                None: Modifies the maze in-place by closing walls between
                cells.
            Note:
                - Operates on 2x3 (width x height) and 3x2 rectangular areas
                - Each identified open area gets one wall placement with a
                randomized gap
                - Process repeats until convergence or max_passes limit is
                reached
            """

            def is_open_between(wall: str, x: int, y: int) -> bool:
                """
                Check if there is an open passage between the current cell and
                an adjacent cell.
                Determines whether a wall between the cell at (x, y) and its
                neighbor in the
                direction specified by 'wall' is open (passable).
                Args:
                    wall (str): The wall identifier indicating the direction
                    to check
                               (e.g., 'north', 'south', 'east', 'west').
                    x (int): The x-coordinate of the current cell.
                    y (int): The y-coordinate of the current cell.
                Returns:
                    bool: True if the passage between the current cell and the
                    adjacent cell
                          is open (both walls are False), False otherwise.
                          Returns False if either cell does not exist or if
                          either wall is closed.
                """
                cell: Cell | None = self.get_cell(x, y)
                if cell and cell.walls[wall]:
                    return False

                _, dx, dy = self.find_direction_by_wall(wall)
                next_x, next_y = x + dx, y + dy
                next_cell: Cell | None = self.get_cell(next_x, next_y)
                if next_cell:
                    return next_cell.walls[self.opposite_wall(wall)] is False
                return False

            def close_between(wall: str, x: int, y: int) -> None:
                """
                Close the wall between two adjacent cells.

                Given a wall direction and coordinates, this function closes
                the wall
                on both sides - setting the wall as closed for the current
                cell and
                closing the opposite wall for the adjacent cell in the
                specified direction.

                Args:
                    wall (str): The direction of the wall to close (e.g.,
                    'north', 'south', 'east', 'west').
                    x (int): The x-coordinate of the first cell.
                    y (int): The y-coordinate of the first cell.
                """
                _, dx, dy = self.find_direction_by_wall(wall)
                next_x, next_y = x + dx, y + dy

                c1: Cell | None = self.get_cell(x, y)
                c2: Cell | None = self.get_cell(next_x, next_y)
                if c1:
                    c1.walls[wall] = True
                if c2:
                    c2.walls[self.opposite_wall(wall)] = True

            def is_open_2x3(x: int, y: int) -> bool:
                """
                Check if a 2x3 rectangular area is completely open (no walls
                blocking passage).
                Verifies that a region starting at coordinates (x, y) with
                width 2 and height 3
                has no internal walls. Checks all vertical walls between
                columns and all
                horizontal walls between rows within the specified region.
                Args:
                    x (int): The x-coordinate of the top-left corner of the
                    region.
                    y (int): The y-coordinate of the top-left corner of the
                    region.
                Returns:
                    bool: True if the 2x3 region is completely open with no
                    blocking walls, False if any walls are present or if the
                    region extends beyond maze bounds.
                """
                if x + 1 >= self.maze.width or y + 2 >= self.maze.height:
                    return False

                # Check vertical walls
                for cx in (x, x + 1):
                    if not is_open_between(Walls.S.value, cx, y):
                        return False
                    if not is_open_between(Walls.S.value, cx, y + 1):
                        return False

                # Check horizontal walls
                for cy in (y, y + 1, y + 2):
                    if not is_open_between(Walls.E.value, x, cy):
                        return False

                return True

            def is_open_3x2(x: int, y: int) -> bool:
                """
                Check if a 3x2 rectangular area is open (traversable) in the
                maze.

                Verifies that all walls within a 3-column by 2-row region are
                open,
                allowing movement through the area. Checks:
                - East walls for columns x and x+1 across rows y and y+1
                - South walls for columns x, x+1, and x+2 at row y

                Args:
                    x: The x-coordinate (column) of the top-left corner of the
                    area.
                    y: The y-coordinate (row) of the top-left corner of the
                    area.

                Returns:
                    True if all walls in the 3x2 area are open, False
                    otherwise.
                    Also returns False if the area extends beyond maze
                    boundaries.
                """
                if x + 2 >= self.maze.width or y + 1 >= self.maze.height:
                    return False

                # Check horizontal walls
                for cy in (y, y + 1):
                    if not is_open_between(Walls.E.value, x, cy):
                        return False
                    if not is_open_between(Walls.E.value, x + 1, cy):
                        return False

                # Check vertical walls
                for cx in (x, x + 1, x + 2):
                    if not is_open_between(Walls.S.value, cx, y):
                        return False

                return True

            def build_wall_2x3(x: int, y: int) -> None:
                """
                Build a 2x3 wall structure with a random gap.
                Creates a vertical wall spanning 3 rows at the specified
                x-coordinate, with a randomly positioned gap in one of the
                three rows. The gap is created
                by skipping the wall closure for that row.
                Args:
                    x (int): The x-coordinate where the wall structure will be
                    built.
                    y (int): The starting y-coordinate of the wall structure
                    (covers y, y+1, y+2).
                Returns:
                    None
                """
                gap_row = random.choice([y, y + 1, y + 2])
                for cy in (y, y + 1, y + 2):
                    if cy == gap_row:
                        continue
                    close_between(Walls.E.value, x, cy)

            def build_wall_3x2(x: int, y: int) -> None:
                """
                Build a horizontal wall of 3 cells with a random gap.

                Creates a wall segment spanning 3 columns (x, x+1, x+2) at row
                y, with a randomly selected column left open (no wall). This
                function is typically used in maze generation to create wall
                structures with controlled passages.

                Args:
                    x (int): The starting x-coordinate (leftmost column) of
                    the wall segment.
                    y (int): The y-coordinate (row) where the wall will be
                    built.

                Returns:
                    None
                """
                gap_col = random.choice([x, x + 1, x + 2])
                for cx in (x, x + 1, x + 2):
                    if cx == gap_col:
                        continue
                    close_between(Walls.S.value, cx, y)

            """ Look for open areas of 2x3 or 3x2 cells to avoid large open
            spaces in the maze."""
            for _ in range(max_passes):
                changed: bool = False

                for y in range(self.maze.height):
                    for x in range(self.maze.width):
                        if is_open_2x3(x, y):
                            build_wall_2x3(x, y)
                            changed = True

                        if is_open_3x2(x, y):
                            build_wall_3x2(x, y)
                            changed = True

                if not changed:
                    break

        def perfect_maze(
            self,
            start: tuple[int, int],
            exit: tuple[int, int],
            is_perfect: bool = True,
            algorithm: str = MazeAlgorithm.DFS.value,
        ) -> None:
            """
            Generate a maze from a starting point to an exit point using the
            specified algorithm.

            This method creates either a perfect maze (no loops, all cells are
            connected) or a non-perfect maze (with additional wall openings)
            by employing depth-first search (DFS) or Prim's algorithm. The
            maze is initialized if not already done, and walls are removed
            based on the perfection setting.

            Args:
                start (tuple[int, int]): The (x, y) coordinates of the maze
                starting point.
                exit (tuple[int, int]): The (x, y) coordinates of the maze
                exit point.
                is_perfect (bool, optional): If True, generates a perfect maze
                with no loops.
                    If False, removes approximately 15% of walls to create a
                    non-perfect maze.
                    Defaults to True.
                algorithm (str, optional): The maze generation algorithm to
                use.
                    Options are Maze_Algorithm.DFS.value or Maze_Algorithm.
                    PRIM.value.
                    Defaults to Maze_Algorithm.DFS.value.

            Returns:
                None

            Raises:
                SystemExit: If the starting and exit positions are not valid.

            Side Effects:
                - Initializes the maze grid if not already initialized.
                - Marks the start and exit cells.
                - Sets the maze watermark.
                - Modifies cell walls based on the selected algorithm.
                - Opens additional areas in the maze.
            """
            if not self.maze.grid_maze:
                self.maze.initial_matrix()

            random.seed(self.maze.seed_code)

            def non_perfect_maze(walls_to_open: int = 20) -> None:
                """
                Creates a non-perfect maze by randomly removing walls between
                cells.
                A non-perfect maze contains loops and multiple paths to the
                destination, as opposed to a perfect maze which has exactly
                one path between any two points.
                This method randomly selects cells in the maze and opens walls
                between them
                and their neighbors, creating circular paths and alternative
                routes.
                Args:
                    walls_to_open (int, optional): The number of walls to
                    remove from the maze.
                        Defaults to 20.
                Returns:
                    None
                Note:
                    - Walls are only removed between valid cells within maze
                    bounds.
                    - Walls are not removed if either cell has the FORTY_TWO
                    property set.
                    - When a wall is removed between two cells, the opposite
                    wall in the
                      neighbor cell is also removed to maintain consistency.
                """
                for _ in range(walls_to_open):
                    x: int = random.randint(1, self.maze.width - 2)
                    y: int = random.randint(1, self.maze.height - 2)
                    cell: Cell | None = self.get_cell(x, y)

                    if cell and cell.walls:
                        w_rm: str = random.choice(list(cell.walls.keys()))

                        # Opening opposite wall of the neighbor
                        offset_x, offset_y = 0, 0
                        if w_rm == Walls.N.value:
                            offset_y = -1
                        elif w_rm == Walls.S.value:
                            offset_y = 1
                        elif w_rm == Walls.E.value:
                            offset_x = 1
                        elif w_rm == Walls.W.value:
                            offset_x = -1

                        neighbor: Cell | None = self.get_cell(
                            x + offset_x, y + offset_y
                        )
                        if (
                            neighbor
                            and not neighbor.is_FORTY_TWO
                            and not cell.is_FORTY_TWO
                        ):
                            cell.walls[w_rm] = False
                            neighbor.walls[self.opposite_wall(w_rm)] = False

            def dfs(cell: Cell) -> None:
                """
                Perform depth-first search to generate maze using recursive
                backtracking.
                Marks the given cell as visited and recursively visits
                unvisited neighbors,
                removing walls between connected cells. Neighbors are shuffled
                to create randomized maze paths. Walls are only removed for
                cells that are not marked as FORTY_TWO (special cells that may
                have fixed walls).
                Args:
                    cell (Cell): The current cell to process in the maze
                    generation algorithm.
                Returns:
                    None
                """
                cell.visited = True

                # shuffle the neighbors
                neighbors: List[tuple[Cell, str]] = self.get_neighbors(cell)
                random.shuffle(neighbors)

                for next_cell, wall in neighbors:
                    if not next_cell.visited:
                        if not cell.is_FORTY_TWO:
                            # break the wall
                            cell.walls[wall] = False
                            if not next_cell.is_FORTY_TWO:
                                op_w: str = self.opposite_wall(wall)
                                next_cell.walls[op_w] = False

                        # recursive call
                        dfs(next_cell)

            def prim(cell: Cell) -> None:
                """
                Generate a maze using Prim's algorithm starting from the given
                cell.

                This iterative implementation of Prim's algorithm marks cells
                as visited and creates passages by removing walls between the
                current cell and unvisited neighboring cells. It uses a
                frontier list to randomly select the next cell
                to visit, ensuring a randomized maze generation.

                Args:
                    cell (Cell): The starting cell from which to begin maze
                    generation.

                Returns:
                    None

                Note:
                    - Modifies the visited state and walls of cells in the maze
                    - Skips cells that are already visited or marked as
                    FORTY_TWO
                    - Uses random selection of frontier cells for varied maze
                    patterns
                """
                cell.visited = True

                frontier: List[tuple[Cell, Cell, str]] = []
                for neigh, wall in self.get_neighbors(cell):
                    frontier.append((neigh, cell, wall))

                while frontier:
                    idx: int = random.randrange(len(frontier))
                    candidate, origin, wall = frontier.pop(idx)

                    if candidate.visited or candidate.is_FORTY_TWO:
                        continue

                    candidate.visited = True
                    origin.walls[wall] = False
                    candidate.walls[self.opposite_wall(wall)] = False

                    for neigh, wall in self.get_neighbors(candidate):
                        if not neigh.visited:
                            frontier.append((neigh, candidate, wall))

            starting_cell_maze: Cell | None = self.get_cell(*start)
            if starting_cell_maze:
                starting_cell_maze.is_start = True

            exit_cell_maze: Cell | None = self.get_cell(*exit)
            if exit_cell_maze:
                exit_cell_maze.is_exit = True
            if starting_cell_maze:
                self.watermark()
                if not self.check_valid_position(start, exit):
                    sys.exit(1)
                if algorithm == MazeAlgorithm.DFS.value:
                    dfs(starting_cell_maze)
                else:
                    prim(starting_cell_maze)

            if not is_perfect:
                # removing a 20% walls according to width * height
                walls_to_remove: int = int(self.maze.width *
                                           self.maze.height * 0.2)
                non_perfect_maze(walls_to_remove)
            self.open_areas()

        def find_cells_without_walls(self, cell: Cell) -> list[str]:
            """
            Find all directions of the cell that don't have walls.

            Args:
                cell: The Cell object to inspect for open directions.

            Returns:
                A list of direction strings (keys) from the cell's walls
                dictionary where the corresponding wall value is False (i.e.,
                no wall exists).

            Example:
                >>> cell = Cell()
                >>> cell.walls = {'north': True, 'south': False,
                    'east': False, 'west': True}
                >>> find_cells_without_walls(cell)
                ['south', 'east']
            """

            return [l for (l, b) in cell.walls.items() if not b]

        def get_cells_solve_maze(self,
                                 start: Cell,
                                 exit: Cell) -> Optional[List[Cell]]:
            """
            Solve the maze using breadth-first search (BFS) algorithm.
            Finds a path from the start cell to the exit cell by exploring the
            maze and tracking parent cells to reconstruct the solution path.
            Args:
                start (Cell): The starting cell for the maze solution.
                exit (Cell): The target/exit cell to reach.
            Returns:
                Optional[List[Cell]]: A list of cells representing the path
                from start to exit,
                                        or None if no path exists.
            Note:
                - Resets the visited state of all cells (except FORTY_TWO
                cells) before solving.
                - Uses BFS to guarantee the shortest path in an unweighted
                maze.
                - Only traverses through cells that have no walls between them.
            """
            # reset visited
            for row in self.maze.grid_maze:
                for col in row:
                    if not col.is_FORTY_TWO:
                        col.visited = False

            list_cells: List[Cell] = [start]
            i: int = 0
            start.visited = True

            parent: dict[Cell, Cell] = {}

            while i < len(list_cells):
                cell = list_cells[i]
                i += 1

                if cell is exit:
                    path: list[Cell] = [cell]
                    while cell in parent:
                        cell = parent[cell]
                        path.append(cell)
                    path.reverse()
                    return path

                cell_wall: list[str] = self.find_cells_without_walls(cell)
                for cw in cell_wall:
                    _, x, y = self.find_direction_by_wall(cw)
                    next_x, next_y = cell.x + x, cell.y + y
                    next_cell: Cell | None = self.get_cell(next_x, next_y)

                    if (
                        next_cell
                        and (not next_cell.visited)
                        and (not next_cell.is_FORTY_TWO)
                    ):
                        next_cell.visited = True
                        parent[next_cell] = cell
                        list_cells.append(next_cell)

            return None

        def path_to_directions(self, path: List[Cell]) -> str:
            """
            Convert a list of cells representing a path into a string of
            directional characters.
            Each movement from one cell to the next is translated into a
            cardinal direction
            character (N, S, E, W) based on the coordinate differences.
            Args:
                path: A list of Cell objects representing consecutive
                positions in a path.
            Returns:
                A string of direction characters where:
                - 'N' represents movement up (dy = -1)
                - 'S' represents movement down (dy = 1)
                - 'E' represents movement right (dx = 1)
                - 'W' represents movement left (dx = -1)
                Returns an empty string if the path contains fewer than 2
                cells.
            Example:
                >>> path = [Cell(0, 0), Cell(0, 1), Cell(1, 1)]
                >>> path_to_directions(path)
                'SE'
            """

            if len(path) < 2:
                return ""

            directions_str: str = ""

            for i in range(len(path) - 1):
                current_cell: Cell = path[i]
                next_cell: Cell = path[i + 1]

                dx: int = next_cell.x - current_cell.x
                dy: int = next_cell.y - current_cell.y

                if dy == -1:  # Move up
                    directions_str += Walls.N.value
                elif dy == 1:  # Move down
                    directions_str += Walls.S.value
                elif dx == 1:  # Move right
                    directions_str += Walls.E.value
                elif dx == -1:  # Move left
                    directions_str += Walls.W.value

            return directions_str

        def solve_maze(self,
                       start: tuple[int, int],
                       exit: tuple[int, int],
                       reg_solve: bool = True) -> str:
            """
            Finds a path through the maze from start to exit and returns
            directions.
            Args:
                start: A tuple of (row, col) coordinates for the maze start
                position.
                exit: A tuple of (row, col) coordinates for the maze exit
                position.
            Returns:
                A string containing directional commands representing the path
                from start to exit.
                Returns an empty string if no path is found or if start/exit
                positions are invalid.
            Raises:
                None. Prints an error message to console if no path exists
                between start and exit.
            """
            string_directions: str = ""
            if ((not self.maze.solve_maze_seed and
               len(self.maze.solve_maze_seed) == 0) or
               reg_solve):
                _start: Cell | None = self.get_cell(*start)
                _end: Cell | None = self.get_cell(*exit)
                if _start is not None and _end is not None:
                    list_solve = self.get_cells_solve_maze(_start, _end)
                    if list_solve is not None:
                        string_directions = self.path_to_directions(list_solve)
                    else:
                        print(
                            f"{Colors.RED.value}"
                            "No path found from start to exit."
                            f"{Colors.RESET.value}"
                        )
            else:
                string_directions = self.maze.solve_maze_seed

            return string_directions
